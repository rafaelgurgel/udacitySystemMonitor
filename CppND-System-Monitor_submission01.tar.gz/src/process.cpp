#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>
#include <iostream>

#include "linux_parser.h"
#include "process.h"

using std::string;
using std::to_string;
using std::vector;
using std::ifstream;
using std::istringstream;
using std::istream_iterator;

// Constructor
Process::Process(int proc_id, long frequency_value) : pid(proc_id), frequency(frequency_value) {
	string l;
  	ifstream stream(LinuxParser::kProcDirectory + to_string(proc_id) + LinuxParser::kStatFilename);
  	getline(stream, l);
  	istringstream lstream(l);
  	istream_iterator<string> beg(lstream), end;
  	vector<string> statInfo(beg, end);
  	
  	start_time = stof(statInfo[21]);
  	cstime = stof(statInfo[16]);
  	stime = stof(statInfo[14]);
  	
  	utime = stof(statInfo[13]);
  	cutime = stof(statInfo[15]);
} 

// simple accessors
int Process::Pid() { return pid; }
string Process::Command() { return LinuxParser::Command(pid); }
string Process::Ram() { return LinuxParser::Ram(pid); }
string Process::User() { return LinuxParser::User(LinuxParser::Uid(pid)); }

long int Process::UpTime() {
  long up_time = LinuxParser::UpTime();
  long secs = up_time - (start_time/frequency);
  return secs;
}
float Process::CpuUtilization() { 
  long up_time = LinuxParser::UpTime();
  float total_time = cutime + cstime + utime + stime;
  // extract to private method to avoid repetition on real use case
  long secs = up_time - (start_time/frequency); 
  float usage_cpu = (total_time / frequency) / secs;
  return usage_cpu;
}

bool Process::operator<(Process &a) {
  return CpuUtilization() < a.CpuUtilization();
}