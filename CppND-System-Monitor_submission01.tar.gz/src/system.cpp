#include <unistd.h>
#include <cstddef>
#include <set>
#include <string>
#include <vector>

#include "process.h"
#include "processor.h"
#include "system.h"
#include "linux_parser.h"

using std::set;
using std::size_t;
using std::string;
using std::vector;


Processor& System::Cpu() { return cpu_; }


vector<Process>& System::Processes() {
  bool changed = false;
  vector<int> current_pids = LinuxParser::Pids();

  for (std::size_t i = 0; i < current_pids.size(); ++i) {
    int current_pid = current_pids[i];  
    if (std::find_if(processes_.begin(), processes_.end(),
                     [current_pid](Process& n) {
                       return n.Pid() == current_pid;
                     }) == processes_.end()) {
      changed = true;
      Process process(current_pids[i], sysconf(_SC_CLK_TCK));  
      processes_.push_back(process);
    }
  }
  for (size_t i = 0; i < processes_.size(); i++) {
    int current_pid = processes_[i].Pid();

    if (std::find(current_pids.begin(), current_pids.end(), current_pid) ==
        current_pids.end()) {
      changed = true;
      processes_.erase(processes_.begin() + i);
    }
  }
  if (changed) {
    std::sort(processes_.begin(), processes_.end(), [](Process &a, Process &b){ return b < a; });
  }
  return processes_;
}

// Helper functions
std::string System::Kernel() { return LinuxParser::Kernel(); }
float System::MemoryUtilization() { return LinuxParser::MemoryUtilization(); }
std::string System::OperatingSystem() { return LinuxParser::OperatingSystem(); }
int System::RunningProcesses() { return LinuxParser::RunningProcesses(); }
int System::TotalProcesses() { return LinuxParser::TotalProcesses(); }
long int System::UpTime() { return LinuxParser::UpTime(); }