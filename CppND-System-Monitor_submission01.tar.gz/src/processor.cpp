#include <string>
#include <vector>

#include "processor.h"
#include "linux_parser.h"

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() {
  	std::vector<std::string> cpu_utilisation = LinuxParser::CpuUtilization();
	
  	float idle = stof(cpu_utilisation[3]);
  	float iowait = stof(cpu_utilisation[4]);
  	
  	float irq = stof(cpu_utilisation[5]);	
  	float softirq = stof(cpu_utilisation[6]);	
  	
  	float system = stof(cpu_utilisation[2]);
  	float user = stof(cpu_utilisation[0]);	
  	
  	float nice = stof(cpu_utilisation[1]);
  	float steal = stof(cpu_utilisation[7]);	
  
  	float p_idle = previous_iowait + previous_idle;
  	float p_n_idle = (previous_user + previous_system + previous_softirq + previous_irq + previous_nice + previous_steal);
  	
  	float curr_idle = iowait + idle;
  	float n_idle = (user + system + irq + softirq +  nice + steal);
  
  	float old_total = p_idle + p_n_idle;
  	float curr_total = curr_idle + n_idle;
  
  	float delta_idle = curr_idle - p_idle;
  	float delta_total = curr_total - old_total;
  	
  	float cpu_perc = (delta_total - delta_idle)/ delta_total;
  	
  	PreviousIdle(idle);	
  	PreviousIowait(iowait);	
  	
  	PreviousIrq(irq);
  	PreviousSoftIrq(softirq);
  	
  	PreviousSystem(system);
  	PreviousUser(user);
  	
  	PreviousNice(nice);
  	PreviousSteal(steal);

  	return cpu_perc;  	
}