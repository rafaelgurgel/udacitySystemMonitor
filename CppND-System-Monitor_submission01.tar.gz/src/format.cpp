#include <string>
#include <sstream>
#include <iomanip>

#include "format.h"

using std::string;
using std::stringstream;
using std::fixed;
using std::setprecision;
using std::to_string;

// get elapsed time
string Format::ElapTime(long secs){// Use long to avoid problems with max int value of 65536
	int h = 0;
    int m = 0;
    int s = 0;
  
  	h = secs/3600; // convert to hours
  	secs = secs % 3600; // get seconds left after counting hours
  
  	m = secs/60; // Get number of minutes
  	secs = secs % 60; // get amount of seconds left
  
  	s = secs;
  
  	return Format(h) + ":" + Format(m) + ":" + Format(s);
}
//show in megabytes
string Format::ShowInMB(float kbytes){
	float mbytes = kbytes/1024;
  	stringstream text_stream;
	text_stream << fixed << setprecision(1) << mbytes;
  	//convert to string and return value
  	return text_stream.str();
}
//presenter function
string Format::Format(int t){
	string time = to_string(t);
    return string(2 - time.length(), '0') + time;
}

