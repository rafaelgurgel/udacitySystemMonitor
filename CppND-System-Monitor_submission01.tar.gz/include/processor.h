#ifndef PROCESSOR_H
#define PROCESSOR_H

class Processor {
 public:
  float Utilization();  // TODO: See src/processor.cpp
  void PreviousIdle(float idle){ previous_idle = idle; };	
  void PreviousIowait(float iowait){ previous_iowait = idle; };
  void PreviousIrq(float irq){ previous_irq = irq; }; // maybe could be an int?
  void PreviousSoftIrq(float softirq){ previous_softirq = softirq; };
  void PreviousSystem(float system){ previous_system = system; };
  void PreviousUser(float user){ previous_user = user; };
  void PreviousNice(float nice){ previous_nice = nice; };
  void PreviousSteal(float steal){ previous_steal = steal; };
 private:
  float idle, iowait, irq, softirq;
  float system, user, nice, steal;
  float p_idle, previous_iowait, previous_idle;
  float p_n_idle, previous_user, previous_system, previous_softirq, previous_irq, previous_nice, previous_steal;
  float curr_idle, n_idle;
  float old_total, curr_total;
  float delta_idle, delta_total;
};

#endif