#ifndef FORMAT_H
#define FORMAT_H

#include <string>
using std::string;

namespace Format {
string ElapTime(long secs); 
string ShowInMB(float kbytes);
string Format(int t);
};                                    // namespace Format

#endif